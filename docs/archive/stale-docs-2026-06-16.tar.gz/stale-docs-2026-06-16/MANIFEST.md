# Stale Docs Archive

Archive date: 2026-06-16

This archive contains documentation that was removed from the active tree because it was one of:

- explicitly legacy or archived
- a point-in-time audit, work log, or implementation summary
- a version-locked project/implementation plan
- an outdated contract/spec replaced by a current canonical source
- generated research byproducts that do not belong in the active docs tree

Archived files:

- `docs/1.0.0-vertical-slice.md`
  - Historical 1.0.0 planning/contract slice with old release assumptions.
- `docs/CONTRACT_SURFACE.md`
  - Outdated v1 contract summary; active contract truth now lives in current canonical schemas, source contracts, and maintained docs.
- `docs/DOCUMENTATION_AUDIT.md`
  - Point-in-time audit for v2.1.0.
- `docs/DX-003-implementation-summary.md`
  - Point-in-time implementation summary for a completed issue.
- `docs/STORE_CONTRACTS.md`
  - Outdated high-level store summary superseded by `src/memory/store/CONTRACT.md`.
- `docs/dev/LEX-1.0.0-WORK-LOG.md`
  - Historical work log.
- `docs/dev/type-and-lint-status.md`
  - Point-in-time status snapshot.
- `docs/legacy/personas/README.md`
  - Explicitly archived persona index.
- `docs/legacy/personas/eager-pm.md`
  - Archived persona moved to LexRunner.
- `docs/legacy/personas/senior-dev.md`
  - Archived persona moved to LexRunner.
- `docs/releases/CATCH_UP_GUIDE.md`
  - One-off release reconciliation guide.
- `docs/research/adjacency-constrained-episodic-memory.aux`
  - Generated LaTeX build artifact.
- `docs/research/adjacency-constrained-episodic-memory.log`
  - Generated LaTeX build artifact.
- `docs/research/adjacency-constrained-episodic-memory.out`
  - Generated LaTeX build artifact.
- `docs/specs/AX-AI-EXPERIENCE_REVIEW.md`
  - Draft review/perspective document with no active operational authority.
- `docs/specs/AX-IMPLEMENTATION-PLAN.md`
  - Version-locked implementation roadmap with stale gates/status.
- `docs/specs/FRAME-SCHEMA-V3.md`
  - Outdated frame spec; canonical source of truth is `src/shared/types/frame-schema.ts`.
- `docs/specs/lex-2.0.0-instructions-contract.md`
  - Draft 2.0.0 contract superseded by maintained instructions docs/specs.
- `docs/specs/lex-2.0.0-project-plan.md`
  - Historical 2.0.0 project plan.
- `src/shared/types/FRAME.md`
  - Outdated frame schema prose superseded by `src/shared/types/frame-schema.ts`.
- `src/memory/store/README.md`
  - Stale storage walkthrough lagging the live schema and migration surface.
- `migrations/README.md`
  - Outdated migration guide with stale schema version and execution notes.
- `migrations/000_reference_schema.sql`
  - Drift-prone reference schema retained only as archive material.
